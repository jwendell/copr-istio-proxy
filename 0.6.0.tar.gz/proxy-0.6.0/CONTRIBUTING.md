# Contribution guidelines

So, you want to hack on the Istio proxy? Yay! Please refer to Istio's overall
[contribution guidelines](https://github.com/istio/istio/blob/master/DEV-GUIDE.md)
to find out how you can help.
